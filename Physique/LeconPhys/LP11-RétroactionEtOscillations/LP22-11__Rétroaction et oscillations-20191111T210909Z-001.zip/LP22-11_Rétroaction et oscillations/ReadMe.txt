LP22 (LP-11 AgregSp�ciale) : R�troaction et oscillations
Pierre Ghesqui�re

Vous trouverez : 
-Plan d�taill� :  "LP22-ScripV2.pdf" (ancienne version avant la le�on : LP22-ScriptV1.pdf)
-Slides
-Simulation sur Scilab/Xcos.
-Tutoriel pour Scilab/Xcos. Pensez � t�l�charger la version 5.4.1 de Scilab et pas les versions ult�rieures !
-Biblio : Contenant mon cours de pr�pa sur les syst�mes boucl�s dans lequel on explique les conditions d'obtentions d'oscillations (j'ajouterai la doc de Leymarie d�s que je la re�ois)

